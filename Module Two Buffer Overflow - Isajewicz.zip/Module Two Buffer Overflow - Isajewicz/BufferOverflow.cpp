/* CS-405 Secure Coding - 2024 C-3
* Module Two: Buffer Overflow
* Instructor Joseph Conlan
* Gregory Isajewicz
*/

// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_order
	//  varaible, and its position in the declaration. It must always be directly before the variable used for input.
	const std::string account_number = "CharlieBrown42";  // Do not Modify
	char user_input[20];									// Do not Modify

	while (true) { // loop allows continuous retry
		bool valid = false; // Variable for input validation

		while (!valid) {
			std::string input_str; // Hold input for validation
			std::cout << std::endl << "Enter a value: ";

			std::getline(std::cin, input_str); // get input

			/* An alternate method which simply takes the first 19 characters and a newline and ignores the rest of the input */
			//std::cin >> std::setw(20) >> user_input; // Set Width limits cin input
			//std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Clear input buffer to newline

			// Input validation: check length 
			if (input_str.length() <= 19) {  //check size of input
				input_str.copy(user_input, sizeof(user_input) - 1);  //copy input_str to user_input
				user_input[input_str.length()] = '\0'; // add null terminator at end 
				valid = true;  //set flag to true
			}
			else {  // If validation check failed - dsplay message to user, flag still false reiterates while loop
				std::cout << "Invalid input. Input cannot exceed 19 characters." << std::endl;
			} 
		}

		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
